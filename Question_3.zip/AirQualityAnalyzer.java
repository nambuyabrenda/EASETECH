import java.util.*;

public class AirQualityAnalyzer {
    public static void main(String[] args) {
        Random rand = new Random();
        int[] aqi = new int[30];
        List<Integer> readings = new ArrayList<>();
        int hazardousDays = 0;

        for (int i = 0; i < 30; i++) {
            aqi[i] = rand.nextInt(300) + 1;
            readings.add(aqi[i]);
            if (aqi[i] > 200) {
                hazardousDays++;
            }
        }

        Collections.sort(readings);
        int median = readings.get(14); // Median value for 30 sorted elements

        System.out.println("Median AQI: " + median);
        System.out.println("Number of hazardous days: " + hazardousDays);
    }
}